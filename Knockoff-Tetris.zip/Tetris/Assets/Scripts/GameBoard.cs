﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameBoard : MonoBehaviour {

    public static Transform[,] gameBoard = new Transform[20, 20];

    public static int redScore = 0;
    public static int blueScore = 0;
    public static int greenScore = 0;
    public static int lines = 0;

    public static bool DeleteAllFullRows() {

        for (int row = 0; row < 20; ++row) {

            if (IsRowFull(row)) {

                DeleteRow(row);

                return true;
            }

        }
        return false;

    }

    public static bool IsRowFull(int row) {

        for (int col = 0; col < 20; ++col) {

            if (gameBoard[col, row] == null) {

                return false;

            }
        }
        return true;
    }

    public static void DeleteRow(int row) {

        for (int col = 0; col < 20; ++col) {

            if (gameBoard[col, row].gameObject.GetComponent<SpriteRenderer>().color == Color.red) {
                redScore++;
            } else if (gameBoard[col, row].gameObject.GetComponent<SpriteRenderer>().color == Color.blue) {
                blueScore++;
            } else if (gameBoard[col, row].gameObject.GetComponent<SpriteRenderer>().color == Color.green) {
                greenScore++;
            }

            Destroy(gameBoard[col, row].gameObject);

            gameBoard[col, row] = null;
        }

        lines++;
        updateScore();
        row++;

        for (int j = row; j < 20; ++j) {

            for (int col = 0; col < 20; ++col) {

                if (gameBoard[col, j] != null) {

                    gameBoard[col, j - 1] = gameBoard[col, j];

                    gameBoard[col, j] = null;

                    gameBoard[col, j - 1].position += new Vector3(0, -1);

                }
            }
        }
    }

    public static void updateScore() {
        var redScore = GameObject.Find("Red Score").GetComponent<Text>();
        var blueScore = GameObject.Find("Blue Score").GetComponent<Text>();
        var greenScore = GameObject.Find("Green Score").GetComponent<Text>();
        var lines = GameObject.Find("Lines").GetComponent<Text>();
        redScore.text = "Red Score: " + GameBoard.redScore.ToString();
        blueScore.text = "Blue Score: " + GameBoard.blueScore.ToString();
        greenScore.text = "Green Score: " + GameBoard.greenScore.ToString();
        lines.text = "Lines: " + GameBoard.lines.ToString();
    }
}