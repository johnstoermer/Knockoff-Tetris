﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Shape : MonoBehaviour {

    public static float speed = 1;
    float lastMoveDown = 0;

    void Start() {
        if (!IsInGrid()) {
            Invoke("OpenGameOverScene", .5f); //wait .5 then gameover
        }
        InvokeRepeating("IncreaseSpeed", 2f, 2f);
    }

    void OpenGameOverScene() {
        Destroy(gameObject);
        SceneManager.LoadScene("GameOver");
    }

    void IncreaseSpeed() {
        Shape.speed -= .001f;
    }

    void Update() {
        if (Input.GetKeyDown("w")) {
            transform.Rotate(0, 0, 90);

            if (!IsInGrid()) {
                transform.Rotate(0, 0, -90);
            } else {
                UpdateGameBoard();
            }
        }

        if (Input.GetKeyDown("a")) {
            transform.position += new Vector3(-1, 0, 0);
            if (!IsInGrid()) {
                transform.position += new Vector3(1, 0, 0);
            } else {
                UpdateGameBoard();
            }

        }

        if (Input.GetKeyDown("s") || Time.time - lastMoveDown >= Shape.speed) {
            transform.position += new Vector3(0, -1, 0);

            if (!IsInGrid()) {
                transform.position += new Vector3(0, 1, 0);

                bool rowDeleted = GameBoard.DeleteAllFullRows();

                if (rowDeleted) {
                    GameBoard.DeleteAllFullRows();
                }

                enabled = false;

                FindObjectOfType<ShapeSpawner>().SpawnShape();

            } else {
                UpdateGameBoard();
            }

            lastMoveDown = Time.time;

        }

        if (Input.GetKeyDown("d")) {
            transform.position += new Vector3(1, 0, 0);

            if (!IsInGrid()) {
                transform.position += new Vector3(-1, 0, 0);
            } else {
                UpdateGameBoard();
            }
        }
    }

    public Vector2 RoundVector(Vector2 vect) {
        return new Vector2(Mathf.Round(vect.x),
            Mathf.Round(vect.y));
    }

    public static bool IsInBorder(Vector2 pos) {
        return ((int)pos.x >= 0 && (int)pos.x <= 19 && (int)pos.y >= 0);
    }

    public bool IsInGrid() {
        foreach (Transform childBlock in transform) {
            Vector2 vect = RoundVector(childBlock.position);
            if (!IsInBorder(vect)) {
                return false;
            }
            if (GameBoard.gameBoard[(int)vect.x, (int)vect.y] != null &&
                GameBoard.gameBoard[(int)vect.x, (int)vect.y].parent != transform) {
                return false;
            }
        }
        return true;
    }

    public void UpdateGameBoard() {

        for (int row = 0; row < 20; ++row) {

            for (int col = 0; col < 20; ++col) {

                if (GameBoard.gameBoard[col, row] != null && GameBoard.gameBoard[col, row].parent == transform) {
                    GameBoard.gameBoard[col, row] = null;
                }
            }
        }

        foreach (Transform childBlock in transform) {

            Vector2 vect = RoundVector(childBlock.position);

            GameBoard.gameBoard[(int)vect.x, (int)vect.y] = childBlock;
        }
    }
}
